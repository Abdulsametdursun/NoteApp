export type User = {
  fullName: string;
  email: string;
  image: string;
};
